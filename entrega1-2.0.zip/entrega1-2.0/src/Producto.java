
public class Producto {

	private String nombre;
	private double precio;
	private String UPC;

	/**
	 * Constructor del producto
	 * 
	 * @param nombre
	 *            Nombre del Producto
	 * @param precio
	 *            Precio del Producto
	 * @param UPC
	 *            Codigo Universal del Producto
	 */
	public Producto(String nombre, double precio, String UPC) {
		this.nombre = nombre;
		this.precio = precio;
		this.UPC = UPC;
	}

	/**
	 * Devuelve el nombre del producto
	 * 
	 * @return Nombre del producto
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Devuelve el precio del producto
	 * 
	 * @return Precio del producto
	 */
	public double getPrecio() {
		return precio;
	}

	/**
	 * Devuelve el Codigo Universal del producto
	 * 
	 * @return UPC del producto
	 */
	public String getUPC() {
		return UPC;
	}

	/**
	 * Devuelve el codigo de la compañia del producto
	 * 
	 * @param UPC
	 * @return Codigo de compañia del producto
	 */
	public String getCodigoCompañia() {
		return UPC.substring(0,6);
	}

	/**
	 * Devuelve el codigo del producto
	 * 
	 * @param UPC
	 * @return Codigo del producto
	 */
	public String getCodigoProducto() {
		return UPC.substring(6,11);
	}

	/**
	 * Devuelve el digito de control del producto(último digito del UPC)
	 * 
	 * @param UPC
	 * @return Digito de control del producto
	 */
	public int getDigitoControl() {
		int s = 0, m = 0;
		String[] tmp = UPC.split("");
		int[] enteros = new int[11];
		for (int i = 0; i < enteros.length; i++) {
			enteros[i] = Integer.parseInt(tmp[i]);
		}
		for (int i = 0; i < 10; i++) {
			if(i%2==0){
				s=s+3*enteros[i];
			}else{
				s=s+enteros[i];
			}
		}
		while (m < s) {
			m += 10;
		}
		return Math.abs(s - m);
	}

}
