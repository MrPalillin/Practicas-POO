import static org.junit.Assert.*;

import java.util.ArrayList;
import fabricante.externo.tarjetas.TarjetaMonedero;
import org.junit.Test;

public class MaquinaVendingTest {

	int[] UPC1 = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 };
	Producto ej1 = new Producto("Nueces", 0.50, UPC1);
	int[] UPC2 = { 1, 3, 5, 7, 9, 2, 4, 6, 8, 1, 3 };
	Producto ej2 = new Producto("Cacao", 1.50, UPC2);
	ArrayList<Producto> listaejemplo = new ArrayList<Producto>();
	ArrayList<Integer> cantidad = new ArrayList<Integer>();

	@Test
	public void testPreguntaPrecio() {
		listaejemplo.add(ej1);
		listaejemplo.add(ej2);
		cantidad.add(4);
		cantidad.add(0);
		MaquinaVending maquina = new MaquinaVending(listaejemplo, cantidad);
		assertTrue(maquina.preguntaPrecio(1) == 0.50);
		assertTrue(maquina.preguntaPrecio(2) == 1.50);
	}

	@Test(expected = AssertionError.class)
	public void testPreguntaPrecioError() {
		listaejemplo.add(ej1);
		listaejemplo.add(ej2);
		cantidad.add(4);
		cantidad.add(0);
		MaquinaVending maquina = new MaquinaVending(listaejemplo, cantidad);
		assertTrue(maquina.preguntaPrecio(1) == 1.50);
		assertTrue(maquina.preguntaPrecio(2) == 0.50);
	}

	@Test
	public void testCompraProducto() {
		listaejemplo.add(ej1);
		listaejemplo.add(ej2);
		cantidad.add(4);
		cantidad.add(1);
		MaquinaVending maquina = new MaquinaVending(listaejemplo, cantidad);
		TarjetaMonedero tarjeta = new TarjetaMonedero("A156Bv09_1zXo894", 5.00);
		TarjetaMonedero tarjetavacia = new TarjetaMonedero("A156Bv09_1zXo894", 0);
		assertNotNull(maquina.compraProducto(1, tarjeta));
		assertNotNull(maquina.compraProducto(2, tarjeta));
		assertNull(maquina.compraProducto(3, tarjeta));
		assertNull(maquina.compraProducto(1, tarjetavacia));
	}
	
	@Test(expected=AssertionError.class)
	public void testCompraProductoError() {
		listaejemplo.add(ej1);
		listaejemplo.add(ej2);
		cantidad.add(4);
		cantidad.add(1);
		MaquinaVending maquina = new MaquinaVending(listaejemplo, cantidad);
		TarjetaMonedero tarjeta = new TarjetaMonedero("A156Bv09_1zXo894", 5.00);
		TarjetaMonedero tarjetavacia = new TarjetaMonedero("A156Bv09_1zXo894", 0);
		assertNull(maquina.compraProducto(1, tarjeta));
		assertNull(maquina.compraProducto(2, tarjeta));
		assertNotNull(maquina.compraProducto(3, tarjeta));
		assertNotNull(maquina.compraProducto(1, tarjetavacia));
	}

}
