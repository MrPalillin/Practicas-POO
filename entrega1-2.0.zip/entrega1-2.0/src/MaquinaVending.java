import java.util.ArrayList;

import fabricante.externo.tarjetas.TarjetaMonedero;

public class MaquinaVending {

	private ArrayList<Producto> listaProductos;
	private ArrayList<Integer> cantidad;

	/**
	 * Constructor de la maquina de vending
	 * 
	 * @param listaProductos
	 *            Los productos en la máquina identificados por la posicion del
	 *            ArrayList
	 * @param cantidad
	 *            Número de productos en dicha posición
	 */
	public MaquinaVending(ArrayList<Producto> listaProductos, ArrayList<Integer> cantidad) {
		this.listaProductos = listaProductos;
		this.cantidad = cantidad;
	}

	/**
	 * Devuelve el precio de un producto en una línea concreta
	 * 
	 * @param linea
	 *            Identificador de línea
	 * @return Precio de dicho producto
	 */
	public double preguntaPrecio(int linea) {
		return listaProductos.get(linea - 1).getPrecio();
	}

	/**
	 * Devuelve un producto al comprador
	 * 
	 * @param linea
	 *            Identificador de linea del producto
	 * @param tarjeta
	 *            Tarjeta con la que se realiza el pago
	 * @return Producto comprado(o null si no queda producto en la linea o la
	 *         tarjeta no tiene saldo suficiente)
	 */
	public Producto compraProducto(int linea, TarjetaMonedero tarjeta) {
		try {
			if (cantidad.get(linea - 1) < 1) {
				return null;
			} else if (linea <= 0 || linea > listaProductos.size()) {
				return null;
			} else if (tarjeta.getSaldoActual() < listaProductos.get(linea - 1).getPrecio()) {
				return null;
			} else {
				cantidad.add(cantidad.get(linea - 1) - 1);
				if (cantidad.get(linea - 1) <= 0) {
					listaProductos.set(linea - 1, null);
				}
				return listaProductos.get(linea - 1);
			}
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

}
