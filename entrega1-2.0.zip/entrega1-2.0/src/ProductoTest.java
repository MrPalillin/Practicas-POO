import static org.junit.Assert.*;

import org.junit.Test;

public class ProductoTest {
	
	@Test
	public void testGetNombre() {
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertEquals(prueba.getNombre(),"Galletas");
	}
	
	@Test(expected=AssertionError.class)
	public void testGetNombreError() {
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertEquals(prueba.getNombre(),"Zumo");
	}

	@Test
	public void testGetPrecio() {
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==2.5);
	}
	
	@Test
	public void testGetPrecioCero() {
		Producto prueba=new Producto("Galletas",0.0,"12345678912");
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==0);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetPrecioError() {
		Producto prueba=new Producto("Galletas",3.50,"12345678912");
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==2.50);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetPrecioErrorNegativo() {
		Producto prueba=new Producto("Galletas",-2.50,"12345678912");
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==2.50);
	}

	@Test
	public void testGetUPC() {
		String codigoprueba="12345678912";
		Producto prueba=new Producto("Galletas",-2.50,"12345678912");
		assertEquals(prueba.getUPC(), codigoprueba);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetUPCError() {
		String codigoprueba="12345678987";
		Producto prueba=new Producto("Galletas",-2.50,"12345678912");
		assertEquals(prueba.getUPC(), codigoprueba);
	}

	@Test
	public void testGetCodigoCompañia() {
		String codigoprueba="123456";
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertEquals(prueba.getCodigoCompañia(), codigoprueba);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetCodigoCompañiaError() {
		String codigoprueba="78912";
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertEquals(prueba.getCodigoCompañia(), codigoprueba);
	}

	@Test
	public void testGetCodigoProducto() {
		String codigoprueba="78912";
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertEquals(prueba.getCodigoProducto(), codigoprueba);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetCodigoProductoError() {
		int[] codigoprueba={1,2,3,4,5};
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertEquals(prueba.getCodigoProducto(), codigoprueba);
	}

	@Test
	public void testGetDigitoControl() {
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertSame(prueba.getDigitoControl(),4);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetDigitoControlError() {
		Producto prueba=new Producto("Galletas",2.50,"12345678912");
		assertSame(prueba.getDigitoControl(),5);
	}
}
