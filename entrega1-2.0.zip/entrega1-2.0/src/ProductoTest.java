import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class ProductoTest {
	
	@Test
	public void testGetNombre() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertEquals(prueba.getNombre(),"Galletas");
	}
	
	@Test(expected=AssertionError.class)
	public void testGetNombreError() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertEquals(prueba.getNombre(),"Zumo");
	}

	@Test
	public void testGetPrecio() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==2.5);
	}
	
	@Test
	public void testGetPrecioCero() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",0.0,UPC);
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==0);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetPrecioError() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",3.50,UPC);
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==2.50);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetPrecioErrorNegativo() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",-2.50,UPC);
		assertTrue(prueba.getPrecio()>=0.0);
		assertTrue(prueba.getPrecio()==2.50);
	}

	@Test
	public void testGetUPC() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		int[] codigoprueba={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",-2.50,UPC);
		assertTrue(Arrays.equals(prueba.getUPC(), codigoprueba));
	}
	
	@Test(expected=AssertionError.class)
	public void testGetUPCError() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		int[] codigoprueba={1,2,3,4,5,6,7,8,9,8,7,0};
		Producto prueba=new Producto("Galletas",-2.50,UPC);
		assertTrue(Arrays.equals(prueba.getUPC(),codigoprueba));
	}

	@Test
	public void testGetCodigoCompañia() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		int[] codigoprueba={1,2,3,4,5,6};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertTrue(Arrays.equals(prueba.getCodigoCompañia(), codigoprueba));
	}
	
	@Test(expected=AssertionError.class)
	public void testGetCodigoCompañiaError() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		int[] codigoprueba={7,8,9,1,2,3};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertTrue(Arrays.equals(prueba.getCodigoCompañia(), codigoprueba));
	}

	@Test
	public void testGetCodigoProducto() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		int[] codigoprueba={7,8,9,1,2};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertTrue(Arrays.equals(prueba.getCodigoProducto(),codigoprueba));
	}
	
	@Test(expected=AssertionError.class)
	public void testGetCodigoProductoError() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		int[] codigoprueba={1,2,3,4,5};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertTrue(Arrays.equals(prueba.getCodigoProducto(),codigoprueba));
	}

	@Test
	public void testGetDigitoControl() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertSame(prueba.getDigitoControl(),4);
	}
	
	@Test(expected=AssertionError.class)
	public void testGetDigitoControlError() {
		int[] UPC={1,2,3,4,5,6,7,8,9,1,2,0};
		Producto prueba=new Producto("Galletas",2.50,UPC);
		assertSame(prueba.getDigitoControl(),5);
	}
}
