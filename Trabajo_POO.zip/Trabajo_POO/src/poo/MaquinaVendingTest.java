package poo;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import fabricante.externo.tarjetas.TarjetaMonedero;

public class MaquinaVendingTest {

	private ArrayList<Producto> huecosMaquina = new ArrayList<Producto>();
	private ArrayList<Integer> cantidad = new ArrayList<Integer>();
	TarjetaMonedero tarjeta=new TarjetaMonedero("A156Bv09_1zXo894", 5.00);

	@Test
	public void testMaquinaVending() {
		this.huecosMaquina = huecosMaquina;
		this.cantidad = cantidad;
	}

	@Test
	public void testRellenaMaquina() {
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(1.00, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		cantidad.add(5);
		assertEquals("Compañia correcto", 123456, prueba1.getCompañia(prueba1.getUPC()));
		assertEquals("Identificador correcto", 78911, prueba1.getIDProducto(prueba1.getUPC()));
		assertEquals("Digito control correcto", 4, prueba1.control(prueba1.getUPC()));
	}

	@Test(expected = AssertionError.class)
	public void testRellenaMaquinaError() {
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(-2.50, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		assertTrue("Error,precio negativo", prueba1.getPrecio() > 0);
	}

	@Test
	public void testCantidades() {
		cantidad.add(5);
		assertTrue("Cantidad admisible", (int) cantidad.get(0) > 0);
		assertEquals("Cantidad correcta", 5, (int) cantidad.get(0));
	}

	@Test(expected = AssertionError.class)
	public void testCantidadesError() {
		cantidad.add(-1);
		assertTrue("Error", (int) cantidad.get(0) > 0);
	}

	@Test
	public void testMostrarLista() {
		cantidad.add(5);
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(2.50, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		System.out.print("1 . " + prueba1.getNombre() + " " + cantidad.get(0));
	}

	@Test(expected=Error.class)
	public void testMostrarListaError() {
		cantidad.add(5);
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(2.50, "Palmera Avellanas", "123456", "78911", 1, UPC0);
		assertEquals("Error,Cadenas en vez de numeros",123456,prueba1.getCompañia(prueba1.getUPC()));
		assertEquals("Error,Cadenas en vez de numeros",78911,prueba1.getIDProducto(prueba1.getUPC()));
		System.out.print("1 . " + prueba1.getNombre() + " " + cantidad.get(0));
	}

	@Test
	public void testPreguntarPrecio() {
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(2.50, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		System.out.println("Precio del producto " + prueba1.getNombre() + " : "
				+ prueba1.getPrecio());
		assertTrue("Precio correcto",prueba1.getPrecio()>0);
	}

	@Test(expected=AssertionError.class)
	public void testPreguntarPrecioError() {
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(-1.50, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		System.out.println("Precio del producto nº " + prueba1.getNombre() + " : "
				+ prueba1.getPrecio());
		assertTrue("Error,precio negativo",prueba1.getPrecio()>0);
	}

	@Test
	public void testComprarProducto() {
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(2.50, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		cantidad.add(2);
		Producto compra=null;
		if(tarjeta.getSaldoActual()<prueba1.getPrecio()){
			System.out.println("Operacion denegada,saldo insuficiente");
		}else{
			cantidad.add(0,cantidad.get(0)-1);
			tarjeta.descontarDelSaldo("6Z1y00Nm31aA-571",3.50);
			compra=prueba1;
		}
		assertNotNull("Compra aceptada",compra);
	}

	@Test(expected=AssertionError.class)
	public void testComprarProductoError() {
		int[] UPC0 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1 };
		Producto prueba1 = new Producto(6.50, "Palmera Avellanas", 123456, 78911, 1, UPC0);
		cantidad.add(2);
		Producto compra=null;
		if(tarjeta.getSaldoActual()<prueba1.getPrecio()){
			System.out.println("Operacion denegada,saldo insuficiente");
		}else{
			cantidad.add(0,cantidad.get(0)-1);
			tarjeta.descontarDelSaldo("6Z1y00Nm31aA-571",3.50);
			compra=prueba1;
		}
		assertNotNull("Compra aceptada",compra);
	}

}
