package poo;

import static org.junit.Assert.*;

import org.junit.Test;

public class MaquinaVendingTest {

	@Test
	public void testMaquinaVending() {
		fail("Not yet implemented");
	}

	@Test
	public void testRellenaMaquina() {
		fail("Not yet implemented");
	}

	@Test
	public void testCantidades() {
		fail("Not yet implemented");
	}

	@Test
	public void testMostrarLista() {
		fail("Not yet implemented");
	}

	@Test
	public void testPreguntarPrecio() {
		fail("Not yet implemented");
	}

	@Test
	public void testComprarProducto() {
		fail("Not yet implemented");
	}

}
