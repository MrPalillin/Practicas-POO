package poo;

import static org.junit.Assert.*;
import org.junit.Assert;
import org.junit.Test;

/**
 * 
 * @author daniel
 * @author dancres
 */

public class ProductoTest {

	private double precio;
	private String nombre;
	private int compañia;
	private int IDProducto;
	private int[] UPC;
	private int digitoControl;
	private int cantidad;

	/**
	 * Inicializa el producto con sus atributos
	 * 
	 * @param precio
	 *            Define el precio del producto
	 * @param nombre
	 *            Define el nombre del producto
	 * @param compañia
	 *            Define la compañia a la que pertenece el producto
	 * @param IDProducto
	 *            Identificador del producto
	 * @param digitoControl
	 *            Basado en una formula
	 * @param UPC
	 *            Codigo de barras del producto
	 */

	public ProductoTest() {
		this.precio = precio;
		this.nombre = nombre;
		this.compañia = compañia;
		this.IDProducto = IDProducto;
		this.digitoControl = digitoControl;
		this.UPC = UPC;
		this.cantidad = cantidad;
	}

	@Test
	public void testSetCantidad() {
		cantidad = 5;
		assertEquals("Elemento correcto", 5, cantidad);
		cantidad = -1;
		assertNotEquals("Elemento incorrecto", 5, cantidad);
	}

	@Test(expected = Error.class)
	public void testSetCantidadError() {
		cantidad = 5;
		assertEquals("Elemento correcto", 5, cantidad);
		cantidad = "5";
		assertEquals("Error", 5, cantidad);
	}

	@Test
	public void testGetCompañia() {
		compañia = 123456;
		assertEquals("Elemento correcto", 123456, compañia);
		compañia = 111111;
		assertNotEquals("Elemento incorrecto", 123456, compañia);
	}

	@Test(expected = Error.class)
	public void testGetCompañiaError() {
		compañia = 123456;
		assertEquals("Elemento correcto", 123456, compañia);
		compañia = "123456";
		assertEquals("Error", 123456, compañia);
	}

	@Test
	public void testGetIDProducto() {
		IDProducto = 57984;
		assertEquals("Elemento correcto", 57984, IDProducto);
		IDProducto = 29958;
		assertNotEquals("Elemento incorrecto", 57984, IDProducto);
	}

	@Test(expected = AssertionError.class)
	public void testGetIDProductError() {
		IDProducto = 57984;
		assertEquals("Elemento correcto", 57984, IDProducto);
		IDProducto = -64823;
		assertEquals("Elemento incorrecto", 57984, IDProducto);
	}

	@Test
	public void testGetNombre() {
		nombre = "Alubias";
		assertSame("Nombre es una cadena", nombre, "Alubias");
	}

	@Test(expected = Error.class)
	public void testGetNombreError() {
		nombre = Alubias;
		assertSame("Error", nombre, "Alubias");
	}

	@Test
	public void testGetPrecio() {
		precio = 2.50;
		assertTrue("Precio correcto", precio > 0);
		precio = 0.50;
		assertNotEquals("Precio incorrecto", 2.50, precio);

	}

	@Test(expected = AssertionError.class)
	public void testGetPrecioError() {
		precio = -0.50;
		assertTrue(precio > 0);
	}

	@Test
	public void testGetUPC() {
		int[] UPC = { 1, 2, 3, 4, 5, 6, 5, 7, 9, 8, 4, 2 };
		assertEquals("UPC correcto", 2, UPC[11]);
		UPC[11] = 3;
		assertNotEquals("UPC incorrecto", 2, UPC[11]);
	}

	@Test(expected = AssertionError.class)
	public void testGetUPCError() {
		int[] UPC = { 1, 2, 3, 4, 5, 6, 5, 7, 9, 8, 4, -1 };
		assertEquals("UPC correcto", 2, UPC[11]);
	}

	@Test
	public void testGetCantidad() {
		cantidad = 2;
		assertEquals("Cantidad correcta", 2, cantidad);
		cantidad = 5;
		assertNotEquals("Cantidad incorrecta", 2, cantidad);
	}

	@Test(expected = AssertionError.class)
	public void testGetCantidadError() {
		cantidad = -2;
		assertTrue("Cantidad correcta", cantidad > 0);
	}

	@Test
	public void testControl() {
		int[] UPC = { 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, -1 };
		int s = 0, m = 0, digitoFinal;
		for (int i = 0; i < 10; i++) {
			if (i % 2 == 0) {
				s = s + 3 * UPC[i];
			} else {
				s = s + UPC[i];
			}
		}
		System.out.print(s);
		while (s > m) {
			m = m + 10;
		}
		digitoFinal = Math.abs(s - m);
		UPC[11] = digitoFinal;
		assertEquals("Digito correcto", 5, digitoFinal);
	}

	@Test(expected = AssertionError.class)
	public void testControlError() {
		int[] UPC = { 0, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, -1 };
		int s = 0, m = 0, digitoFinal;
		for (int i = 0; i < 10; i++) {
			if (i % 2 == 0) {
				s = s + 3 * UPC[i];
			} else {
				s = s + UPC[i];
			}
		}
		while (s > m) {
			m = m + 10;
		}
		digitoFinal = Math.abs(s - m);
		UPC[11] = digitoFinal;
		assertEquals("Digito correcto", 5, digitoFinal);
	}

}
